

#ifndef __MUIC_INTERNAL_H__
#define __MUIC_INTERNAL_H__

#include <linux/muic/common/muic.h>

enum ioctl_cmd {
	GET_COM_VAL = 0x01,
	GET_CTLREG = 0x02,
	GET_ADC = 0x03,
	GET_SWITCHING_MODE = 0x04,
	GET_INT_MASK = 0x05,
	GET_REVISION = 0x06,
	GET_OTG_STATUS = 0x7,
	GET_CHGTYPE = 0x08,
	GET_RESID3 = 0x09,
};

enum switching_mode{
	SWMODE_MANUAL = 0,
	SWMODE_AUTO = 1,
};




enum com_index {
	COM_OPEN = 1,
	COM_OPEN_WITH_V_BUS = 2,
	COM_UART_AP = 3,
	COM_UART_CP = 4,
	COM_USB_AP  = 5,
	COM_USB_CP  = 6,
	COM_AUDIO   = 7,
};

enum{
	ADC_SCANMODE_CONTINUOUS = 0x0,
	ADC_SCANMODE_ONESHOT = 0x1,
	ADC_SCANMODE_PULSE = 0x2,
};

enum vps_type{
	VPS_TYPE_SCATTERED = 0,
	VPS_TYPE_TABLE = 1,
};


typedef struct _muic_vps_scatterred_type {
    u8  val1;
    u8  val2;
    u8  val3;
    u8  adc;
    u8  vbvolt;
} vps_scatterred_type;

typedef struct _muic_vps_table_t {
	u8  adc;
	u8  vbvolt;
	u8  adc1k;
	u8  adcerr;
	u8  adclow;
	u8  chgdetrun;
	u8  chgtyp;
	u8  DCDTimedout;
	const char *vps_name;
	const muic_attached_dev_t attached_dev;
	u8 status[3];
	u8 control[4];
	u8 hvcontrol[2];
} vps_table_type;

struct muic_intr_data {
	u8	intr1;
	u8	intr2;
};

struct muic_irq_t {
	int irq_adc1k;
	int irq_adcerr;
	int irq_adc;
	int irq_chgtyp;
	int irq_vbvolt;
	int irq_dcdtmr;
};

typedef union _muic_vps_t {
	vps_scatterred_type s;
	vps_table_type t;
	char vps_data[120];
} vps_data_t;


struct regmap_desc;

typedef struct _muic_data_t {

	struct device *dev;
	struct i2c_client *i2c; 
	struct mutex muic_mutex;

	
	struct muic_platform_data *pdata;

	void *muic_data;

	
	muic_attached_dev_t attached_dev;

	vps_data_t vps;
	int vps_table;

	struct muic_intr_data intr;
	struct muic_irq_t irqs;

	
	struct regmap_desc *regmapdesc;

	char *chip_name;

	int gpio_uart_sel;

	
	u8 muic_vendor;			
	u8 muic_version;		

	bool			is_gamepad;
	bool			is_factory_start;
	bool			is_rustproof;
	bool			is_otg_test;
	struct delayed_work	init_work;
	struct delayed_work	usb_work;

	bool			is_muic_ready;
	bool			undefined_range;
	bool			discard_interrupt;
	bool			is_dcdtmr_intr;
	bool 			is_dcp_charger;
	bool			is_afc_reset;
	bool			is_afc_pdic_ready;

	struct hv_data		*phv;

#if defined(CONFIG_USB_EXTERNAL_NOTIFY)
	
	struct notifier_block	usb_nb;
#endif

#if defined(CONFIG_MUIC_SUPPORT_CCIC)
	
	muic_attached_dev_t	legacy_dev;

#ifdef CONFIG_USB_TYPEC_MANAGER_NOTIFIER
	struct notifier_block	manager_nb;
#else
	struct notifier_block	ccic_nb;
#endif

	struct delayed_work	ccic_work;

	
	enum muic_op_mode	opmode;
	bool 			afc_water_disable;
#endif

	
	int (*com_to_open_with_vbus)(void *);
	int (*switch_to_ap_usb)(void *);
	int (*switch_to_ap_uart)(void *);
	int (*switch_to_cp_uart)(void *);
	int (*get_vbus)(void *);
	void (*set_jig_state)(void *, bool val);
	void (*set_cable_state)(void *, muic_attached_dev_t new_dev);
	void (*dcd_rescan)(void *);
	void (*set_afc_reset)(void *);
	void (*set_water_detect)(void *, bool val);
} muic_data_t;

extern struct device *switch_device;

#endif 
