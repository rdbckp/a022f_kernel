
#ifndef SCSI_TRANSPORT_ISCSI_H
#define SCSI_TRANSPORT_ISCSI_H

#include <linux/device.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <scsi/iscsi_if.h>

struct scsi_transport_template;
struct iscsi_transport;
struct iscsi_endpoint;
struct Scsi_Host;
struct scsi_cmnd;
struct iscsi_cls_conn;
struct iscsi_conn;
struct iscsi_task;
struct sockaddr;
struct iscsi_iface;
struct bsg_job;
struct iscsi_bus_flash_session;
struct iscsi_bus_flash_conn;


struct iscsi_transport {
	struct module *owner;
	char *name;
	unsigned int caps;

	struct iscsi_cls_session *(*create_session) (struct iscsi_endpoint *ep,
					uint16_t cmds_max, uint16_t qdepth,
					uint32_t sn);
	void (*destroy_session) (struct iscsi_cls_session *session);
	struct iscsi_cls_conn *(*create_conn) (struct iscsi_cls_session *sess,
				uint32_t cid);
	int (*bind_conn) (struct iscsi_cls_session *session,
			  struct iscsi_cls_conn *cls_conn,
			  uint64_t transport_eph, int is_leading);
	int (*start_conn) (struct iscsi_cls_conn *conn);
	void (*stop_conn) (struct iscsi_cls_conn *conn, int flag);
	void (*destroy_conn) (struct iscsi_cls_conn *conn);
	int (*set_param) (struct iscsi_cls_conn *conn, enum iscsi_param param,
			  char *buf, int buflen);
	int (*get_ep_param) (struct iscsi_endpoint *ep, enum iscsi_param param,
			     char *buf);
	int (*get_conn_param) (struct iscsi_cls_conn *conn,
			       enum iscsi_param param, char *buf);
	int (*get_session_param) (struct iscsi_cls_session *session,
				  enum iscsi_param param, char *buf);
	int (*get_host_param) (struct Scsi_Host *shost,
				enum iscsi_host_param param, char *buf);
	int (*set_host_param) (struct Scsi_Host *shost,
			       enum iscsi_host_param param, char *buf,
			       int buflen);
	int (*send_pdu) (struct iscsi_cls_conn *conn, struct iscsi_hdr *hdr,
			 char *data, uint32_t data_size);
	void (*get_stats) (struct iscsi_cls_conn *conn,
			   struct iscsi_stats *stats);

	int (*init_task) (struct iscsi_task *task);
	int (*xmit_task) (struct iscsi_task *task);
	void (*cleanup_task) (struct iscsi_task *task);

	int (*alloc_pdu) (struct iscsi_task *task, uint8_t opcode);
	int (*xmit_pdu) (struct iscsi_task *task);
	int (*init_pdu) (struct iscsi_task *task, unsigned int offset,
			 unsigned int count);
	void (*parse_pdu_itt) (struct iscsi_conn *conn, itt_t itt,
			       int *index, int *age);

	void (*session_recovery_timedout) (struct iscsi_cls_session *session);
	struct iscsi_endpoint *(*ep_connect) (struct Scsi_Host *shost,
					      struct sockaddr *dst_addr,
					      int non_blocking);
	int (*ep_poll) (struct iscsi_endpoint *ep, int timeout_ms);
	void (*ep_disconnect) (struct iscsi_endpoint *ep);
	int (*tgt_dscvr) (struct Scsi_Host *shost, enum iscsi_tgt_dscvr type,
			  uint32_t enable, struct sockaddr *dst_addr);
	int (*set_path) (struct Scsi_Host *shost, struct iscsi_path *params);
	int (*set_iface_param) (struct Scsi_Host *shost, void *data,
				uint32_t len);
	int (*get_iface_param) (struct iscsi_iface *iface,
				enum iscsi_param_type param_type,
				int param, char *buf);
	umode_t (*attr_is_visible)(int param_type, int param);
	int (*bsg_request)(struct bsg_job *job);
	int (*send_ping) (struct Scsi_Host *shost, uint32_t iface_num,
			  uint32_t iface_type, uint32_t payload_size,
			  uint32_t pid, struct sockaddr *dst_addr);
	int (*get_chap) (struct Scsi_Host *shost, uint16_t chap_tbl_idx,
			 uint32_t *num_entries, char *buf);
	int (*delete_chap) (struct Scsi_Host *shost, uint16_t chap_tbl_idx);
	int (*set_chap) (struct Scsi_Host *shost, void *data, int len);
	int (*get_flashnode_param) (struct iscsi_bus_flash_session *fnode_sess,
				    int param, char *buf);
	int (*set_flashnode_param) (struct iscsi_bus_flash_session *fnode_sess,
				    struct iscsi_bus_flash_conn *fnode_conn,
				    void *data, int len);
	int (*new_flashnode) (struct Scsi_Host *shost, const char *buf,
			      int len);
	int (*del_flashnode) (struct iscsi_bus_flash_session *fnode_sess);
	int (*login_flashnode) (struct iscsi_bus_flash_session *fnode_sess,
				struct iscsi_bus_flash_conn *fnode_conn);
	int (*logout_flashnode) (struct iscsi_bus_flash_session *fnode_sess,
				 struct iscsi_bus_flash_conn *fnode_conn);
	int (*logout_flashnode_sid) (struct iscsi_cls_session *cls_sess);
	int (*get_host_stats) (struct Scsi_Host *shost, char *buf, int len);
	u8 (*check_protection)(struct iscsi_task *task, sector_t *sector);
};


extern struct scsi_transport_template *iscsi_register_transport(struct iscsi_transport *tt);
extern int iscsi_unregister_transport(struct iscsi_transport *tt);


extern void iscsi_conn_error_event(struct iscsi_cls_conn *conn,
				   enum iscsi_err error);
extern void iscsi_conn_login_event(struct iscsi_cls_conn *conn,
				   enum iscsi_conn_state state);
extern int iscsi_recv_pdu(struct iscsi_cls_conn *conn, struct iscsi_hdr *hdr,
			  char *data, uint32_t data_size);

extern int iscsi_offload_mesg(struct Scsi_Host *shost,
			      struct iscsi_transport *transport, uint32_t type,
			      char *data, uint16_t data_size);

extern void iscsi_post_host_event(uint32_t host_no,
				  struct iscsi_transport *transport,
				  enum iscsi_host_event_code code,
				  uint32_t data_size,
				  uint8_t *data);

extern void iscsi_ping_comp_event(uint32_t host_no,
				  struct iscsi_transport *transport,
				  uint32_t status, uint32_t pid,
				  uint32_t data_size, uint8_t *data);

struct iscsi_cls_conn {
	struct list_head conn_list;	
	void *dd_data;			
	struct iscsi_transport *transport;
	uint32_t cid;			
	struct mutex ep_mutex;
	struct iscsi_endpoint *ep;

	struct device dev;		
};

#define iscsi_dev_to_conn(_dev) \
	container_of(_dev, struct iscsi_cls_conn, dev)

#define transport_class_to_conn(_cdev) \
	iscsi_dev_to_conn(_cdev->parent)

#define iscsi_conn_to_session(_conn) \
	iscsi_dev_to_session(_conn->dev.parent)


enum {
	ISCSI_SESSION_LOGGED_IN,
	ISCSI_SESSION_FAILED,
	ISCSI_SESSION_FREE,
};

#define ISCSI_MAX_TARGET -1

struct iscsi_cls_session {
	struct list_head sess_list;		
	struct iscsi_transport *transport;
	spinlock_t lock;
	struct work_struct block_work;
	struct work_struct unblock_work;
	struct work_struct scan_work;
	struct work_struct unbind_work;

	
	int recovery_tmo;
	bool recovery_tmo_sysfs_override;
	struct delayed_work recovery_work;

	unsigned int target_id;
	bool ida_used;

	
	pid_t creator;
	int state;
	int sid;				
	void *dd_data;				
	struct device dev;	
};

#define iscsi_dev_to_session(_dev) \
	container_of(_dev, struct iscsi_cls_session, dev)

#define transport_class_to_session(_cdev) \
	iscsi_dev_to_session(_cdev->parent)

#define iscsi_session_to_shost(_session) \
	dev_to_shost(_session->dev.parent)

#define starget_to_session(_stgt) \
	iscsi_dev_to_session(_stgt->dev.parent)

struct iscsi_cls_host {
	atomic_t nr_scans;
	struct mutex mutex;
	struct request_queue *bsg_q;
	uint32_t port_speed;
	uint32_t port_state;
};

#define iscsi_job_to_shost(_job) \
        dev_to_shost(_job->dev)

extern void iscsi_host_for_each_session(struct Scsi_Host *shost,
				void (*fn)(struct iscsi_cls_session *));

struct iscsi_endpoint {
	void *dd_data;			
	struct device dev;
	uint64_t id;
	struct iscsi_cls_conn *conn;
};

struct iscsi_iface {
	struct device dev;
	struct iscsi_transport *transport;
	uint32_t iface_type;	
	uint32_t iface_num;	
	void *dd_data;		
};

#define iscsi_dev_to_iface(_dev) \
	container_of(_dev, struct iscsi_iface, dev)

#define iscsi_iface_to_shost(_iface) \
	dev_to_shost(_iface->dev.parent)


struct iscsi_bus_flash_conn {
	struct list_head conn_list;	
	void *dd_data;			
	struct iscsi_transport *transport;
	struct device dev;		
	
	uint32_t		exp_statsn;
	uint32_t		statsn;
	unsigned		max_recv_dlength; 
	unsigned		max_xmit_dlength; 
	unsigned		max_segment_size;
	unsigned		tcp_xmit_wsf;
	unsigned		tcp_recv_wsf;
	int			hdrdgst_en;
	int			datadgst_en;
	int			port;
	char			*ipaddress;
	char			*link_local_ipv6_addr;
	char			*redirect_ipaddr;
	uint16_t		keepalive_timeout;
	uint16_t		local_port;
	uint8_t			snack_req_en;
	
	uint8_t			tcp_timestamp_stat;
	uint8_t			tcp_nagle_disable;
	
	uint8_t			tcp_wsf_disable;
	uint8_t			tcp_timer_scale;
	uint8_t			tcp_timestamp_en;
	uint8_t			ipv4_tos;
	uint8_t			ipv6_traffic_class;
	uint8_t			ipv6_flow_label;
	uint8_t			fragment_disable;
	
	uint8_t			is_fw_assigned_ipv6;
};

#define iscsi_dev_to_flash_conn(_dev) \
	container_of(_dev, struct iscsi_bus_flash_conn, dev)

#define iscsi_flash_conn_to_flash_session(_conn) \
	iscsi_dev_to_flash_session(_conn->dev.parent)

#define ISID_SIZE 6

struct iscsi_bus_flash_session {
	struct list_head sess_list;		
	struct iscsi_transport *transport;
	unsigned int target_id;
	int flash_state;	
	void *dd_data;				
	struct device dev;	
	
	unsigned		first_burst;
	unsigned		max_burst;
	unsigned short		max_r2t;
	int			default_taskmgmt_timeout;
	int			initial_r2t_en;
	int			imm_data_en;
	int			time2wait;
	int			time2retain;
	int			pdu_inorder_en;
	int			dataseq_inorder_en;
	int			erl;
	int			tpgt;
	char			*username;
	char			*username_in;
	char			*password;
	char			*password_in;
	char			*targetname;
	char			*targetalias;
	char			*portal_type;
	uint16_t		tsid;
	uint16_t		chap_in_idx;
	uint16_t		chap_out_idx;
	
	uint16_t		discovery_parent_idx;
	
	uint16_t		discovery_parent_type;
	
	uint8_t			auto_snd_tgt_disable;
	uint8_t			discovery_sess;
	
	uint8_t			entry_state;
	uint8_t			chap_auth_en;
	
	uint8_t			discovery_logout_en;
	uint8_t			bidi_chap_en;
	
	uint8_t			discovery_auth_optional;
	uint8_t			isid[ISID_SIZE];
	uint8_t			is_boot_target;
};

#define iscsi_dev_to_flash_session(_dev) \
	container_of(_dev, struct iscsi_bus_flash_session, dev)

#define iscsi_flash_session_to_shost(_session) \
	dev_to_shost(_session->dev.parent)


#define iscsi_cls_session_printk(prefix, _cls_session, fmt, a...) \
	dev_printk(prefix, &(_cls_session)->dev, fmt, ##a)

#define iscsi_cls_conn_printk(prefix, _cls_conn, fmt, a...) \
	dev_printk(prefix, &(_cls_conn)->dev, fmt, ##a)

extern int iscsi_session_chkready(struct iscsi_cls_session *session);
extern int iscsi_is_session_online(struct iscsi_cls_session *session);
extern struct iscsi_cls_session *iscsi_alloc_session(struct Scsi_Host *shost,
				struct iscsi_transport *transport, int dd_size);
extern int iscsi_add_session(struct iscsi_cls_session *session,
			     unsigned int target_id);
extern int iscsi_session_event(struct iscsi_cls_session *session,
			       enum iscsi_uevent_e event);
extern struct iscsi_cls_session *iscsi_create_session(struct Scsi_Host *shost,
						struct iscsi_transport *t,
						int dd_size,
						unsigned int target_id);
extern void iscsi_remove_session(struct iscsi_cls_session *session);
extern void iscsi_free_session(struct iscsi_cls_session *session);
extern struct iscsi_cls_conn *iscsi_create_conn(struct iscsi_cls_session *sess,
						int dd_size, uint32_t cid);
extern int iscsi_destroy_conn(struct iscsi_cls_conn *conn);
extern void iscsi_unblock_session(struct iscsi_cls_session *session);
extern void iscsi_block_session(struct iscsi_cls_session *session);
extern int iscsi_scan_finished(struct Scsi_Host *shost, unsigned long time);
extern struct iscsi_endpoint *iscsi_create_endpoint(int dd_size);
extern void iscsi_destroy_endpoint(struct iscsi_endpoint *ep);
extern struct iscsi_endpoint *iscsi_lookup_endpoint(u64 handle);
extern int iscsi_block_scsi_eh(struct scsi_cmnd *cmd);
extern struct iscsi_iface *iscsi_create_iface(struct Scsi_Host *shost,
					      struct iscsi_transport *t,
					      uint32_t iface_type,
					      uint32_t iface_num, int dd_size);
extern void iscsi_destroy_iface(struct iscsi_iface *iface);
extern struct iscsi_iface *iscsi_lookup_iface(int handle);
extern char *iscsi_get_port_speed_name(struct Scsi_Host *shost);
extern char *iscsi_get_port_state_name(struct Scsi_Host *shost);
extern int iscsi_is_session_dev(const struct device *dev);

extern char *iscsi_get_discovery_parent_name(int parent_type);
extern struct device *
iscsi_find_flashnode(struct Scsi_Host *shost, void *data,
		     int (*fn)(struct device *dev, void *data));

extern struct iscsi_bus_flash_session *
iscsi_create_flashnode_sess(struct Scsi_Host *shost, int index,
			    struct iscsi_transport *transport, int dd_size);

extern struct iscsi_bus_flash_conn *
iscsi_create_flashnode_conn(struct Scsi_Host *shost,
			    struct iscsi_bus_flash_session *fnode_sess,
			    struct iscsi_transport *transport, int dd_size);

extern void
iscsi_destroy_flashnode_sess(struct iscsi_bus_flash_session *fnode_sess);

extern void iscsi_destroy_all_flashnode(struct Scsi_Host *shost);
extern int iscsi_flashnode_bus_match(struct device *dev,
				     struct device_driver *drv);
extern struct device *
iscsi_find_flashnode_sess(struct Scsi_Host *shost, void *data,
			  int (*fn)(struct device *dev, void *data));
extern struct device *
iscsi_find_flashnode_conn(struct iscsi_bus_flash_session *fnode_sess);

extern char *
iscsi_get_ipaddress_state_name(enum iscsi_ipaddress_state port_state);
extern char *iscsi_get_router_state_name(enum iscsi_router_state router_state);
#endif
